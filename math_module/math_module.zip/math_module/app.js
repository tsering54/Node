var math = require('./mathlib')();
console.log(math.add(2,3));
console.log(math.multiple(3,5));
console.log(math.square(5));
console.log(math.random(1,35));
